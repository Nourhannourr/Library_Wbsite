from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.shortcuts import get_object_or_404
from .models import Book,UserProfile
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from django.http import JsonResponse

# Create your views here.

def AdminPage(request):
   return render(request,'pages/Admin.html')

def booklistPage(request):
    return render(request, 'pages/book_list.html') 

def admin_booklistPage(request):
    return render(request, 'pages/book_list.html') 

def bookformPage(request, pk=None):
    # حاول تجيب الكتاب لو جت قيمة pk، أو خلي book = None للإضافة
    book = get_object_or_404(Book, pk=pk) if pk else None

    # جهّز البيانات المشتركة للتمبلت
    context = {
        'all_books':    Book.objects.all(),
        'form_choices': Book.CATEGORY_CHOICES,
        'book':         book,
        'error':        None,
    }

    if request.method == 'POST':
        action      = request.POST.get('action')       # 'add' / 'update' / 'delete'
        title       = request.POST.get('title', '').strip()
        author      = request.POST.get('author', '').strip()
        category    = request.POST.get('category', '').strip()
        description = request.POST.get('description', '').strip()
        image       = request.FILES.get('image')

        # عملية الحذف
        if action == 'delete' and book:
            book.delete()
            return redirect('pages:admin_booklist_page')

        # تحقق من الحقول المطلوبة
        if not (title and author and category):
            context['error'] = "Please fill in title, author, and category."
        else:
            if action == 'update' and book:
                # تعديل الكتاب
                book.title       = title
                book.author      = author
                book.category    = category
                book.description = description
                if image:
                    book.image = image
                book.save()
            else:
                # إضافة كتاب جديد
                Book.objects.create(
                    title=title,
                    author=author,
                    category=category,
                    description=description,
                    image=image
                )
            return redirect('pages:admin_booklist_page')

    # عرض الصفحة (GET أو POST مع أخطاء)
    return render(request, 'pages/book_form.html', context)


def bookDetailPage(request, pk):
    book = get_object_or_404(Book, pk=pk)
    return render(request, 'pages/bookdetails.html', {
        'book': book
    })


@login_required(login_url='pages_user:log')
def borrowBook(request, book_id):
    book = get_object_or_404(Book, pk=book_id)

    if book.status.lower() == 'available':
        book.status = 'Unavailable'
        book.save()

        profile, _ = UserProfile.objects.get_or_create(user=request.user)
        profile.borrowed_books.add(book)

        messages.success(request, f"You have borrowed '{book.title}' successfully! 📚")
    else:
        messages.error(request, f"'{book.title}' is currently unavailable.")

    return redirect('pages_user:book_detail', pk=book_id)


def returnBook(request, book_id):
    # 1) جلب الكتاب والبروفايل
    book = get_object_or_404(Book, pk=book_id)
    profile, _ = UserProfile.objects.get_or_create(user=request.user)

    # 2) لو الكتاب موجود في borrowed_books
    if book in profile.borrowed_books.all():
        profile.borrowed_books.remove(book)
        book.status = 'Available'
        book.save()
        messages.success(request, f"You have returned '{book.title}' successfully.")
    else:
        messages.error(request, f"'{book.title}' was not in your borrowed list.")

    # 3) إما ترجع لصفحة الـ profile أو لتفاصيل الكتاب
    return redirect('pages_user:profile_page')

@login_required(login_url='pages_user:log')
def profilePage(request):
    profile, _ = UserProfile.objects.get_or_create(user=request.user)
    return render(request, 'pages/profile.html', {
        'borrowed_books': profile.borrowed_books.all()
    })




def bookauthorsPage(request):
    return render(request, 'pages/bookauthors.html') 


def admin_bookauthorsPage(request):
    return render(request, 'pages/bookauthors.html')


def signup_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        confirm = request.POST.get('confirm')

        if password != confirm:
            return HttpResponse("Passwords do not match!")

        if User.objects.filter(username=username).exists():
            return HttpResponse("Username already exists")

        user = User.objects.create_user(username=username, email=email, password=password)
        user.save()
        return HttpResponse("OK")

    return render(request, 'pages/signup.html')

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        role = request.POST.get('role') 
        code = request.POST.get('code')

        if role == "admin" and code == "123" and username in ["mo", "mahmoud","mary", "aseel","nourhan", "abdelrhman"]:
            return HttpResponse("admin")  

        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return HttpResponse("user")  
        else:
            return HttpResponse("Invalid credentials")

    return render(request, 'pages/index.html')



def dashPage(request):
    return render(request,'pages/dash.html') 

def admin_dashPage(request):
    return render(request,'pages/dash.html') 

def userprofilePage(request):
    return render(request,'pages/userprofile.html')

def admin_userprofilePage(request):
    return render(request,'pages/userprofile.html') 

def UserPage(request):
   return render(request,'pages/indexx.html')

def booklistCategories(request):
    fiction_books = Book.objects.filter(category__iexact='Fiction')
    nonfiction_books = Book.objects.filter(category__iexact='Non-Fiction')
    mystery_books = Book.objects.filter(category__iexact='Mystery')
    scifi_books = Book.objects.filter(category__iexact='Sci-Fi')
    romance_books = Book.objects.filter(category__iexact='Romance')
    historical_books = Book.objects.filter(category__iexact='Historical')
    horror_books = Book.objects.filter(category__iexact='Horror')
    poetry_books = Book.objects.filter(category__iexact='Poetry')
    psychology_books = Book.objects.filter(category__iexact='Psychology')
    religion_books = Book.objects.filter(category__iexact='Religion')

    return render(request, 'pages/book_list.html', {
        'fiction_books': fiction_books,
        'nonfiction_books': nonfiction_books,
        'mystery_books': mystery_books,
        'scifi_books': scifi_books,
        'romance_books': romance_books,
        'historical_books': historical_books,
        'horror_books': horror_books,
        'poetry_books': poetry_books,
        'psychology_books': psychology_books,
        'religion_books': religion_books,
    })


def filter_books(request):
    title    = request.GET.get('title', '').lower()
    author   = request.GET.get('author', '').lower()
    category = request.GET.get('category', '').lower()

    books = Book.objects.all()
    if title:    books = books.filter(title__icontains=title)
    if author:   books = books.filter(author__icontains=author)
    if category: books = books.filter(category__iexact=category)

    data = [{
        'id':       b.id,
        'title':    b.title,
        'author':   b.author,
        'category': b.category,
    } for b in books]

    return JsonResponse({'books': data})






# def bookDetailPage(request, pk):
#     book = Book.objects.get(id=pk)
#     return render(request, 'pages/bookdetails.html', {'book': book})



