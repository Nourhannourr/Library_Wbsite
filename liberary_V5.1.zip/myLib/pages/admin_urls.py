
from django.urls import path
from . import views
from .views import bookDetailPage


app_name = 'pages'

urlpatterns = [
    path('signup', views.signup_view, name='sign'), 
    path('admin', views.AdminPage, name='admin_page'),
    path('login', views.login_view, name = 'log'),
    # path('bookform/', views.bookformPage, name='book_add'),
    path('bookauthors/', views.bookauthorsPage, name='admin_book_authors_page'),
    path('dashboard/', views.dashPage, name='admin_dash_page'),
    path('profile/', views.userprofilePage, name='admin_profile_page'),
    # path('book/<int:pk>/', views.bookDetailPage, name='book_detail_page'), # i will remove it from admin as user only can see it to borroe
    path('booklist/', views.booklistCategories, name='admin_booklist_page'),
    path('bookform/',           views.bookformPage, name='book_add'),
    path('bookform/<int:pk>/',  views.bookformPage, name='book_edit'),
    path('booklist/',           views.booklistCategories, name='admin_booklist_page'),
    path('filter-books/', views.filter_books, name='filter_books'),###

]