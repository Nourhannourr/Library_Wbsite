

from django.urls import path
from . import views
from .views import bookDetailPage

urlpatterns = [
    path('signup', views.signup_view, name='sign'),
    path('login', views.login_view, name = 'log'),
    path('user', views.UserPage, name='user'),
    path('bookauthors/', views.bookauthorsPage, name='book_authors_page'),
    path('dashboard/', views.dashPage, name='dash_page'),
    path('profile/', views.userprofilePage, name='profile_page'),
    path('booklist/', views.booklistCategories, name='book_list_page'),
    path('book/<int:pk>/',       views.bookDetailPage, name='book_detail'),
    path('borrow/<int:book_id>/', views.borrowBook,    name='borrow_book'),
    path('profile/',              views.profilePage,   name='profile_page'),
    path('return/<int:book_id>/', views.returnBook, name='return_book'),
    path('filter-books/', views.filter_books, name='filter_books'),
]