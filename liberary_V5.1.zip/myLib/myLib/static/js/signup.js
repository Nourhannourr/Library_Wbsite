document.addEventListener("DOMContentLoaded", function () {
  const signupForm = document.getElementById("signupForm");

  signupForm.addEventListener("submit", function (e) {
    e.preventDefault();

    const emailInput = document.getElementById("eemaill");
    const email = emailInput.value;

    // تحقق من الإيميل أولًا
    if (!(email.endsWith("gmail.com") || email.endsWith("email.com"))) {
      alert("Email must end with @gmail.com or @email.com");
      return;  // توقف التنفيذ هنا لو الشرط مش اتحقق
    }

    // لو الإيميل صحيح، نبدأ نرسل البيانات بالـ AJAX
    const formData = new FormData(signupForm);

    fetch(signupForm.action, {
      method: "POST",
      headers: {
        "X-CSRFToken": formData.get("csrfmiddlewaretoken"),
      },
      body: formData,
    })
      .then(response => response.text())
      .then(data => {
        console.log("Server Response:", data);

        if (data.trim() === "OK") {
          window.location.href = "/onlineLibrary/User/login";
        } else {
          alert(data);
        }
      })
      .catch(error => {
        console.error("Error:", error);
        alert("Something went wrong. Please try again.");
      });
  });
});