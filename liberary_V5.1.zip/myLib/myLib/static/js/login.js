document.addEventListener("DOMContentLoaded", function () {
  const loginForm = document.getElementById("loginForm");

  if (!loginForm) return;

  loginForm.addEventListener("submit", function (e) {
    e.preventDefault();

    const formData = new FormData(loginForm);

    fetch(loginForm.action, {
      method: "POST",
      headers: {
        "X-CSRFToken": formData.get("csrfmiddlewaretoken"),
      },
      body: formData,
    })
      .then(response => response.text())
      .then(data => {
        const cleanedData = data.trim();
        console.log("Server Response:", cleanedData);

        if (cleanedData === "Invalid credentials") {
  alert("Invalid credentials");
} else if (cleanedData === "admin") {
  window.location.href = "/onlineLibrary/Admin/admin"; 
} else if (cleanedData === "user") {
  window.location.href = "/onlineLibrary/User/user"; 
} else {
  alert("Unexpected response from server: " + cleanedData);
}
      })
      .catch(error => {
        console.error("Error:", error);
        alert("Something went wrong. Please try again.");
      });
  });
});