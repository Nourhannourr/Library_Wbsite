from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path(
      'onlineLibrary/Admin/',
      include(
        ('pages.admin_urls', 'pages_admin'),
        namespace='pages_admin'
      )
    ),
    path(
      'onlineLibrary/User/',
      include(
        ('pages.user_urls', 'pages_user'),
        namespace='pages_user'
      )
    ),

    path('',include('pages.user_urls')),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)