document.getElementById("book-form").addEventListener("submit", function (e) {
    e.preventDefault();
  
    const id = document.getElementById("book_id").value.trim();
    const name = document.getElementById("name").value.trim();
    const author = document.getElementById("author").value.trim();
    const category = document.getElementById("category").value;
    const description = document.getElementById("description").value.trim();
    const imageInput = document.getElementById("book-image");
  
    if (!id || !name || !author || !category || !description || !imageInput.files.length) {
      alert("Please fill in all fields");
      return;
    }
  
    const reader = new FileReader();
    reader.onload = function () {
      const imageData = reader.result;
  
      const books = JSON.parse(localStorage.getItem("books") || "[]");
      const existingIndex = books.findIndex(b => b.id === id);
  
      const bookData = {
        id,
        name,
        author,
        category,
        description,
        image: imageData
      };
  
      if (existingIndex >= 0) {
        books[existingIndex] = bookData;
      } else {
        books.push(bookData);
      }
  
      localStorage.setItem("books", JSON.stringify(books));
      localStorage.removeItem("editBookId");
  
      window.location.href = "book_list.html";
    };
  
    reader.readAsDataURL(imageInput.files[0]);
  });
  
  window.addEventListener("DOMContentLoaded", () => {
    const editId = localStorage.getItem("editBookId");
    if (editId) {
      const books = JSON.parse(localStorage.getItem("books") || "[]");
      const book = books.find(b => b.id === editId);
      if (book) {
        document.getElementById("book_id").value = book.id;
        document.getElementById("book_id").disabled = true;
        document.getElementById("name").value = book.name;
        document.getElementById("author").value = book.author;
        document.getElementById("category").value = book.category;
        document.getElementById("description").value = book.description;
      }
    }
  }); 